function [p,s] = BlockLoop(app)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
    rng(1);

    global gs_bNet;
    %% Parameters setting
    s_nConst = 2;       % Constellation size (2 = BPSK)
    s_nMemSize = 4;     % Number of taps
    s_fTrainSize = 5000; % Training size
    s_fBlocks = 3; %200;
    v_fSigWdB=  10; %30:40; %6:16; %% % Noise variance in dB

    % RS encoder -  n = 255, t = 8, k = 239
    s_nRSCodeSize = 8;          % Number of bits per symbol
    s_nT = 16;                   % Number of error symbols correctable
    s_nN = 2^s_nRSCodeSize-1;   % Number of coded symobls per block         
    s_nK = s_nN - 2*s_nT;       % Number of uncoded symbols per block

    s_nRSBlockSize = s_nRSCodeSize * s_nK; % number of bits in RS block
    s_nRSWordSize = s_nRSCodeSize * s_nN; % number of bits in RS word
    genpoly = rsgenpoly(s_nN,s_nK); % RS generative polynomial

    gs_bNet = 0;        

    s_nStates = s_nConst^s_nMemSize;    



    % s_fEstErrVar = 0.1;   % Estimation error variance
    % Frame size for generating noisy training
    s_fFrameSize = 100; %1200;
    s_fNumFrames = s_fTrainSize/s_fFrameSize; 

    s_nChannels = 1;            % 1 - LTI channel;  2 - Poisson channel 

    v_nCurves   = [...          % Curves
        1 ...                   % Deep Viterbi - real-time training - 1
        0 ....                  % Deep Viterbi - composite training
        0 ....                  % Deep Viterbi - initial training
        1 ...                   % Viterbi - perfect CSI - 1
        0 ....                  % Viterbi - CSI uncertainty
        0 ....                  % Viterbi - estimate channel
        ];


    s_nCurves = length(v_nCurves);

    v_stProts = strvcat(  ...
        'ViterbiNet, online training', ...
        'ViterbiNet, composite training',...
        'ViterbiNet, initial training',...  
        'Viterbi, full CSI', ...
        'Viterbi, initial CSI',...   
        'Viterbi, LS estimate');
    v_stProts2 = strvcat(  ...
        'First tap (h)_1', ...
        'Second tap (h)_2',...
        'Third tap (h)_3',...  
        'Fourth tap (h)_4');

    v_stPlotType = strvcat( '-rs', '--go',  '-g<', '-.b^',  ':kx',...
       '-g*', '-m>', '-mx', '-c^', '-cv');
    v_stLegend = [];
    if(s_nChannels == 1)
        % Exponentailly decaying channel
        v_fChannel = exp(-0.2*(0:(s_nMemSize-1)));    
        s_nMixtureSize = s_nStates;
    elseif (s_nChannels == 2)
        % Poisson channel
        v_fChannel = exp(-0.2*(0:(s_nMemSize-1)));    
        s_nMixtureSize = 1.5*s_nStates;
    end

    % Channel model - periodic time variatios
    v_nPers = 3*[17, 13, 11, 7];

    m_fTimeVar = 0.8 + 0.2*cos((2*pi./v_nPers)' * (0:s_fBlocks-1))';
    m_fChannel = bsxfun(@times,m_fTimeVar,v_fChannel);

    s_fBERTh = 0.02; %0.35;

    % TODO NIR - add time variations to the channel
    %m_fChannel = kron(ones(s_fBlocks,1),v_fChannel);

    %TODO NIR - cosider replacing GMM fitting with different fitting, see
    % https://stats.stackexchange.com/questions/89189/parameter-estimation-of-a-poisson-mixture-model

    %% Simulation loop
    m_fBER = zeros(s_fBlocks, length(v_fSigWdB), length(v_nCurves));

    % Noisy channels for CSI uncertainty
    % m_fNoisyChanneltest = repmat(fliplr(v_fChannel),s_fTestSize,1) + ...
    %     sqrt(s_fEstErrVar)*randn(s_fTestSize,s_nMemSize);

    % Generate test labels
    m_fXtest = randi(s_nConst,s_fBlocks,s_nRSBlockSize);
    m_bCodedTtest = zeros(s_fBlocks,s_nRSWordSize);
    m_fRtest = zeros(s_fBlocks,s_nRSWordSize);
    for kk=1:s_fBlocks
        % encode bits
        m_bCodedTtest(kk,:) = v_bRSEncode(m_fXtest(kk,:) -1, s_nRSCodeSize, s_nT, genpoly) + 1;
        v_bCodedTtest = m_bCodedTtest(kk,:);
        % Add FEC code
        if(s_nChannels == 1)
            v_fStest = 2*(v_bCodedTtest  - 0.5*(s_nConst+1));
        elseif(s_nChannels == 2)
            v_fStest = v_bCodedTtest -1;
        end
        m_fStest= m_fMyReshape(v_fStest, s_nMemSize); 
        m_fRtest(kk,:) = fliplr(m_fChannel(kk,:)) * m_fStest;
    end

    %%

    % Loop over number of SNR

    s_fSigmaW = 10^(-0.1*v_fSigWdB);
    % LTI AWGN channel
    if(s_nChannels == 1)
        %v_fYtrain = v_Rtrain + sqrt(s_fSigmaW)*randn(size(v_Rtrain));
        %v_fYtrain2 = v_Rtrain2 + sqrt(s_fSigmaW)*randn(size(v_Rtrain2));
        m_fYtest = m_fRtest + sqrt(s_fSigmaW)*randn(size(m_fRtest));
    elseif(s_nChannels == 2)
        %v_fYtrain = poissrnd(sqrt(1/s_fSigmaW)*v_Rtrain + 1);
        %v_fYtrain2 = poissrnd(sqrt(1/s_fSigmaW)*v_Rtrain2 + 1);
        m_fYtest = poissrnd(sqrt(1/s_fSigmaW)*m_fRtest + 1);
    end

    % Load Viterbi net
    for kk=1:s_fBlocks
        % parameters for the result graphs
        if kk ==1
            x1_Taps = 1;
            y1_Taps = m_fChannel(1,1);
            y2_Taps = m_fChannel(1,2);
            y3_Taps = m_fChannel(1,3);
            y4_Taps = m_fChannel(1,4);
            p = plot(app.UIAxesChannelTaps,x1_Taps,y1_Taps,'-b',x1_Taps,y2_Taps,'--m',x1_Taps,y3_Taps,':r',x1_Taps,y4_Taps,'-.g');
            legend(app.UIAxesChannelTaps,v_stProts2,'Location','NorthEast');
            % set x and y DataSource for an updated graph
            %{
            set(p(1,1),'XData',x1_Taps,'YData',y1_Taps)
            set(p(2,1),'XData',x1_Taps,'YData',y2_Taps)
            set(p(3,1),'XData',x1_Taps,'YData',y3_Taps)
            set(p(4,1),'XData',x1_Taps,'YData',y4_Taps)
            %}
            set(p(1,1),'XDataSource', 'x1_Taps')
            set(p(2,1),'XDataSource', 'x1_Taps')
            set(p(3,1),'XDataSource', 'x1_Taps')
            set(p(4,1),'XDataSource', 'x1_Taps')
            set(p(1,1),'YDataSource', 'y1_Taps')
            set(p(2,1),'YDataSource', 'y2_Taps')
            set(p(3,1),'YDataSource', 'y3_Taps')
            set(p(4,1),'YDataSource', 'y4_Taps')
        else
            x1_Taps(kk) = kk;
            y1_Taps(kk) = m_fChannel(kk,1);
            y2_Taps(kk) = m_fChannel(kk,2);
            y3_Taps(kk) = m_fChannel(kk,3);
            y4_Taps(kk) = m_fChannel(kk,4);
            %refreshdata (app.UIAxesChannelTaps)
            refreshdata
            drawnow
        end
        if ((v_nCurves(2) + v_nCurves(1) + v_nCurves(3)) > 0)
            % Initially train network using mean channel
            tic
            if((v_nCurves(1) + v_nCurves(3)) > 0)
                % TODO NIR - here change Ytrain2 to Ytrain
                % Load initial network
                load([pwd filesep 'TrainedNet10_periodic.mat']);
                net2 = net;
                % Load initial PDF
                load([pwd filesep 'GMModel10_periodic.mat']);
                GMModel2 = GMModel;
            end
            toc
            %{
            % Train network using composite channels
            if(v_nCurves(2)==1)
                % Train network using training from composite channels
                learnRate = 0;
                [net3, GMModel3] = GetViterbiNet(v_fXtrain,v_fYtrain2, s_nConst, s_nMemSize, s_nMixtureSize,learnRate);
            end
            %}
            % Loop over blocks:
            %v_PrevXMeta = v_fXtrain;
            %v_fPrevYMeta = v_fYtrain;

            v_fYtest = m_fYtest(kk,:);
            v_fXtest = m_fXtest(kk,:);

            % Use metalearning
            if(v_nCurves(1)==1)
                % Apply ViterbiNet detctor
                v_fXCodedhat =  ApplyViterbiNet(v_fYtest, net, GMModel, s_nConst, s_nMemSize);
                %{
                % Use network to compute likelihood function
                m_fpS_Y = predict(net,num2cell(v_fYtest'));
                % Compute output PDF
                v_fpY = pdf(GMModel, v_fYtest');
                m_fLikelihood = (m_fpS_Y .* v_fpY)*s_nStates;
                % Apply Viterbi output layer
                v_fXCodedhat = v_fViterbi(m_fLikelihood, s_nConst, s_nMemSize);
                %}
                % Decode RS code
                v_fXhat = v_bRSDecode(v_fXCodedhat-1, s_nRSCodeSize, s_nT, genpoly)+1;
                % Evaluate error rate
                m_fBER(kk,1,1) = mean(v_fXhat ~= v_fXtest');
                % Generate meta-training data
                v_fXMetaTrain =  v_bRSEncode(v_fXhat-1, s_nRSCodeSize, s_nT, genpoly)+1;

                % Avoid MATLAB crash when training with too large error
                if (m_fBER(kk,1,1) <=s_fBERTh)
                    % Retrain network
                    net = TrainViterbiNet(m_fMyReshape(v_fXMetaTrain', s_nMemSize),v_fYtest, s_nConst, net.Layers, 0.002); %learning rate
                    %net = TrainViterbiNet(m_fMyReshape(v_fXCodedhat, s_nMemSize),v_fYtest, s_nConst, net.Layers, 0.002);
                    %net =  GetViterbiNet(m_fMyReshape([v_PrevXMeta, v_fXMetaTrain'], s_nMemSize),[v_fPrevYMeta, v_fYtest], s_nConst);

                end
                % Update fitting process - use existing model as strting point
                S = struct('mu',GMModel.mu,'Sigma',GMModel.Sigma,'ComponentProportion',GMModel.ComponentProportion);
                % Avoid zero mixing
                [m,I] = min(S.ComponentProportion);
                while (m <= 0)
                    S.ComponentProportion(I) = 10^(-4);
                    S.ComponentProportion(mod(I+1,s_nMixtureSize) + 1) = ...
                        S.ComponentProportion(mod(I+1,s_nMixtureSize) + 1) - 10^(-4);
                    [m,I] = min(S.ComponentProportion);
                end
                GMModel = fitgmdist(v_fYtest',s_nMixtureSize,'RegularizationValue',0.1, 'Start', S);
                %GMModel = fitgmdist([v_fPrevYMeta, v_fYtest]',s_nMixtureSize,'RegularizationValue',0.1, 'Start', S);

                % Save previous meta-training.
                v_fPrevYMeta = v_fYtest;
                v_PrevXMeta = v_fXMetaTrain';
                % parameters for the result graphs
                if kk == 1
                    x1_BER = 1;
                    y1_BER = m_fBER(1,1,1);
                    v_stLegend = strvcat(v_stLegend,  v_stProts(1,:));
                else
                    x1_BER(kk) = kk;
                    y1_BER(kk) = m_fBER(kk,1,1);
                    v_stLegend = strvcat(v_stLegend,  v_stProts(1,:));
                end
            end
            %{
            % Use composite network
            if(v_nCurves(2)==1)
                % Use network to compute likelihood function
                m_fpS_Y = predict(net3,num2cell(v_fYtest'));
                % Compute output PDF
                v_fpY = pdf(GMModel3, v_fYtest');
                m_fLikelihood = (m_fpS_Y .* v_fpY)*s_nStates;
                % Apply Viterbi output layer
                v_fXCodedhat = v_fViterbi(m_fLikelihood, s_nConst, s_nMemSize);
                % Decode RS code
                v_fXhat = v_bRSDecode(v_fXCodedhat-1, s_nRSCodeSize, s_nT, genpoly)+1;
                % Evaluate error rate
                m_fBER(kk,1,2) = mean(v_fXhat ~= v_fXtest');
            end

            % Use only initially trained network
            if(v_nCurves(3)==1)
                % Use network to compute likelihood function
                m_fpS_Y = predict(net2,num2cell(v_fYtest'));
                % Compute output PDF
                v_fpY = pdf(GMModel2, v_fYtest');
                m_fLikelihood = (m_fpS_Y .* v_fpY)*s_nStates;
                % Apply Viterbi output layer
                v_fXCodedhat = v_fViterbi(m_fLikelihood, s_nConst, s_nMemSize);
                % Decode RS code
                v_fXhat = v_bRSDecode(v_fXCodedhat-1, s_nRSCodeSize, s_nT, genpoly)+1;
                % Evaluate error rate
                m_fBER(kk,1,3) = mean(v_fXhat ~= v_fXtest');
            end
            %}
        end
        % Model-based Viterbi
        if((v_nCurves(4)+v_nCurves(5)+v_nCurves(6))>0)
            v_fEstChannel = v_fChannel;
            % Loop over blocks:
            v_fYtest = m_fYtest(kk,:);
            v_fXtest = m_fXtest(kk,:);
            m_fLikelihood3 = zeros(s_nRSWordSize,s_nStates);
            %m_fLikelihood4 = zeros(s_nRSWordSize,s_nStates);
            %m_fLikelihood6 = zeros(s_nRSWordSize,s_nStates);
            % Compute coditional PDF for each state
            for ii=1:s_nStates
                v_fX = zeros(s_nMemSize,1);
                Idx = ii - 1;
                for ll=1:s_nMemSize
                    v_fX(ll) = mod(Idx,s_nConst) + 1;
                    Idx = floor(Idx/s_nConst);
                end
                if(s_nChannels == 1)
                    v_fS = 2*(v_fX - 0.5*(s_nConst+1));
                    m_fLikelihood3(:,ii) = normpdf(v_fYtest' -  fliplr(m_fChannel(kk,:))*v_fS,0,s_fSigmaW);
                    %m_fLikelihood4(:,ii) = normpdf(v_fYtest' -  fliplr(v_fChannel)*v_fS,0,s_fSigmaW);
                    %m_fLikelihood6(:,ii) = normpdf(v_fYtest' -  fliplr(v_fEstChannel)*v_fS,0,s_fSigmaW);
                elseif(s_nChannels == 2)
                    v_fS = v_fX-1;
                    m_fLikelihood3(:,ii) = poisspdf(v_fYtest', sqrt(1/s_fSigmaW)*fliplr(m_fChannel(kk,:))*v_fS + 1);
                    %m_fLikelihood4(:,ii) = poisspdf(v_fYtest', sqrt(1/s_fSigmaW)* fliplr(v_fChannel)*v_fS + 1);
                    %m_fLikelihood6(:,ii) = poisspdf(v_fYtest', sqrt(1/s_fSigmaW)* fliplr(v_fEstChannel)*v_fS + 1);
                end
            end
            % Debug code
            %v_fpY2 = sum(m_fLikelihood2')/s_nStates;
            % m_fpS_Y2 = (m_fLikelihood2 ./ v_fpY2')/s_nStates;

            % Apply Viterbi output layer                       
            if(v_nCurves(4) == 1)
                v_fXCodedhat = v_fViterbi(m_fLikelihood3, s_nConst, s_nMemSize);
                % Decode RS code
                v_fXhat3 = v_bRSDecode(v_fXCodedhat-1, s_nRSCodeSize, s_nT, genpoly)+1;
                % Evaluate error rate
                m_fBER(kk,1,4) = mean(v_fXhat3 ~= v_fXtest');
                if kk == 1
                    x4_BER = 1;
                    y4_BER = m_fBER(kk,1,4);
                    v_stLegend = strvcat(v_stLegend,  v_stProts(4,:));
                else
                    x4_BER(kk) = kk;
                    y4_BER(kk) = m_fBER(kk,1,4);
                    v_stLegend = strvcat(v_stLegend,  v_stProts(4,:));
                end
            end
            %{
            if(v_nCurves(5) == 1)
                v_fXCodedhat = v_fViterbi(m_fLikelihood4, s_nConst, s_nMemSize);
                % Decode RS code
                v_fXhat4 = v_bRSDecode(v_fXCodedhat-1, s_nRSCodeSize, s_nT, genpoly)+1;
                % Evaluate error rate
                m_fBER(kk,1,5) = mean(v_fXhat4 ~= v_fXtest');
            end
            if(v_nCurves(6) == 1)
                v_fXCodedhat = v_fViterbi(m_fLikelihood6, s_nConst, s_nMemSize);
                % Decode RS code
                v_fXhat6 = v_bRSDecode(v_fXCodedhat-1, s_nRSCodeSize, s_nT, genpoly)+1;
                % Evaluate error rate
                m_fBER(kk,1,6) = mean(v_fXhat6 ~= v_fXtest');
                % Generate meta-training data
                v_fXMetaTrain =  v_bRSEncode(v_fXhat6-1, s_nRSCodeSize, s_nT, genpoly)+1;
                if(s_nChannels == 1)
                    v_fSMetaTrain = 2*(v_fXMetaTrain - 0.5*(s_nConst+1));
                elseif(s_nChannels == 2)
                    v_fSMetaTrain = v_fXMetaTrain-1;
                end
                m_fSMetaTrain = m_fMyReshape(v_fSMetaTrain, s_nMemSize);
                % Update channel estimate
                v_fEstChannel = (inv(m_fSMetaTrain*m_fSMetaTrain.')*m_fSMetaTrain)*(v_fYtest');
                v_fEstChannel = fliplr(v_fEstChannel');
                %m_fChannel(kk,:) + sqrt(s_fEstErrVar)*randn(size(v_fChannel));
            end
            %}
        end

        if kk ==1 %OZ - need to do more robustic for any type of net and curve
            %s= semilogy(x1_BER,y1_BER, v_stPlotType(1,:),x4_BER,y4_BER,v_stPlotType(1,:));
            s= plot(app.UIAxesBER,x1_BER,y1_BER, v_stPlotType(1,:),x4_BER,y4_BER,v_stPlotType(4,:));
            legend(app.UIAxesBER,v_stLegend,'Location','SouthWest');
            %set(s,'Xlim',[1 s_fBlocks])
            set(s(1,1),'XDataSource', 'x1_BER')
            set(s(2,1),'XDataSource', 'x4_BER')
            set(s(1,1),'YDataSource', 'y1_BER')
            set(s(2,1),'YDataSource', 'y4_BER')
            %legend(v_stLegend,'Location','SouthWest');
        else        
            %refreshdata(app.UIAxesBER)
            refreshdata
            drawnow
        end
        kk
    end

end

