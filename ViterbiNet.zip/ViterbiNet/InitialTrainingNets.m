% Deep Viterbi test 2 - introducing metalearning
clear all;
close all;
clc;

rng(1);

global gs_bNet;
%% Parameters setting
s_nConst = 2;       % Constellation size (2 = BPSK)
s_nMemSize = 4;     % Number of taps
s_fTrainSize = 5000; % Training size
s_fBlocks = 50; %200;
v_fSigWdB = 12; %30:40; %6:16; %% % Noise variance in dB

% RS encoder -  n = 255, t = 8, k = 239
s_nRSCodeSize = 8;          % Number of bits per symbol
s_nT = 16;                   % Number of error symbols correctable
s_nN = 2^s_nRSCodeSize-1;   % Number of coded symobls per block         
s_nK = s_nN - 2*s_nT;       % Number of uncoded symbols per block

s_nRSBlockSize = s_nRSCodeSize * s_nK; % number of bits in RS block
s_nRSWordSize = s_nRSCodeSize * s_nN; % number of bits in RS word
genpoly = rsgenpoly(s_nN,s_nK); % RS generative polynomial
        
gs_bNet = 0;        

s_nStates = s_nConst^s_nMemSize;    



% s_fEstErrVar = 0.1;   % Estimation error variance
% Frame size for generating noisy training
s_fFrameSize = 100; %1200;
s_fNumFrames = s_fTrainSize/s_fFrameSize; 

s_nChannels = 1;            % 1 - LTI channel;  2 - Poisson channel 
s_nChannelsModel = 2;       % 1 - Gaussian periodic; 2 - Gaussian decaying
v_nCurves   = [...          % Curves
    0 ...                   % Deep Viterbi - real-time training - 1
    1 ....                  % Deep Viterbi - composite training
    0 ....                  % Deep Viterbi - initial training
    0 ...                   % Viterbi - perfect CSI - 1
    0 ....                  % Viterbi - CSI uncertainty
    0 ....                  % Viterbi - estimate channel
    ];


s_nCurves = length(v_nCurves);

v_stProts = strvcat(  ...
    'ViterbiNet, online training', ...
    'ViterbiNet, composite training',...
    'ViterbiNet, initial training',...  
    'Viterbi, full CSI', ...
    'Viterbi, initial CSI',...   
    'Viterbi, LS estimate');

if(s_nChannels == 1)
    % Exponentailly decaying channel
    v_fChannel = exp(-0.2*(0:(s_nMemSize-1)));    
    s_nMixtureSize = s_nStates;
elseif (s_nChannels == 2)
    % Poisson channel
    v_fChannel = exp(-0.2*(0:(s_nMemSize-1)));    
    s_nMixtureSize = 1.5*s_nStates;
end

% Channel model - periodic/decaying time variatios
v_nPers = 3*[17, 13, 11, 7];
if (s_nChannelsModel == 1)
    m_fTimeVar = 0.8 + 0.2*cos((2*pi./v_nPers)' * (0:s_fBlocks-1))'; % Gaussian periodic time variatios
elseif (s_nChannelsModel == 2)
    m_fTimeVar = 0.6 + 0.4*exp((-2*pi./v_nPers)' * (0:s_fBlocks-1))'; % Gaussian decaying time variatios
end
m_fChannel = bsxfun(@times,m_fTimeVar,v_fChannel);

s_fBERTh = 0.02; %0.35;

% TODO NIR - add time variations to the channel
%m_fChannel = kron(ones(s_fBlocks,1),v_fChannel);

%TODO NIR - cosider replacing GMM fitting with different fitting, see
% https://stats.stackexchange.com/questions/89189/parameter-estimation-of-a-poisson-mixture-model

%% Simulation loop
m_fBER = zeros(s_fBlocks, length(v_fSigWdB), length(v_nCurves));

% Noisy channels for CSI uncertainty
% m_fNoisyChanneltest = repmat(fliplr(v_fChannel),s_fTestSize,1) + ...
%     sqrt(s_fEstErrVar)*randn(s_fTestSize,s_nMemSize);


% Generate initial training labels
v_fXtrain = randi(s_nConst,1,s_fTrainSize);
if(s_nChannels == 1)
    v_fStrain = 2*(v_fXtrain - 0.5*(s_nConst+1));
elseif(s_nChannels == 2)
    v_fStrain = v_fXtrain-1;
end
m_fStrain = m_fMyReshape(v_fStrain, s_nMemSize);

% Training over mean channel only
v_Rtrain = fliplr(v_fChannel) * m_fStrain;


% Training over composite channels
s_fCompositeBlocks = 10;
s_fTrainBlkSize = floor(s_fTrainSize/s_fCompositeBlocks);
m_fRtrain2 = zeros(s_fCompositeBlocks, s_fTrainBlkSize);
for kk=1:s_fCompositeBlocks
    m_fStrain2= m_fMyReshape(v_fStrain(((kk-1)*s_fTrainBlkSize + 1):(kk*s_fTrainBlkSize)), s_nMemSize); 
    m_fRtrain2(kk,:) = fliplr(m_fChannel(3*kk,:)) * m_fStrain2;
end
m_fRtrain2 = m_fRtrain2';
v_Rtrain2 = m_fRtrain2(:)';


s_fSigmaW = 10^(-0.1*v_fSigWdB);
% LTI AWGN channel
if(s_nChannels == 1)
    v_fYtrain = v_Rtrain + sqrt(s_fSigmaW)*randn(size(v_Rtrain));
    v_fYtrain2 = v_Rtrain2 + sqrt(s_fSigmaW)*randn(size(v_Rtrain2));
    %m_fYtest = m_fRtest + sqrt(s_fSigmaW)*randn(size(m_fRtest));
elseif(s_nChannels == 2)
    v_fYtrain = poissrnd(sqrt(1/s_fSigmaW)*v_Rtrain + 1);
    v_fYtrain2 = poissrnd(sqrt(1/s_fSigmaW)*v_Rtrain2 + 1);
    %m_fYtest = poissrnd(sqrt(1/s_fSigmaW)*m_fRtest + 1);
end

% Viterbi net
if ((v_nCurves(2) + v_nCurves(1) + v_nCurves(3)) > 0)
    % Initially train network using mean channel
    tic
    if((v_nCurves(1) + v_nCurves(3)) > 0)
        % TODO NIR - here change Ytrain2 to Ytrain
        % Train network initially
        learnRate = 0;
        [net, GMModel] = GetViterbiNet(v_fXtrain,v_fYtrain, s_nConst, s_nMemSize, s_nMixtureSize,learnRate);
        % Save initial network
        net2 = net;
        % Save initial PDF
        GMModel2 = GMModel;
    end
    toc
    
    % Train network using composite channels
    if(v_nCurves(2)==1)
        % Train network using training from composite channels
        learnRate = 0;
        [net3, GMModel3] = GetViterbiNet(v_fXtrain,v_fYtrain2, s_nConst, s_nMemSize, s_nMixtureSize,learnRate);
    end
    
end
%%
%{
save('TrainedCompositeNet7_decaying.mat','net3');
save('GMModelComposite7_decaying.mat','GMModel3');
save('TrainedNet7_periodic.mat','net');
save('GMModel7_periodic.mat','GMModel');
%}