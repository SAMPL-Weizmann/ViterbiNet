% Deep Viterbi test 2 - introducing metalearning
clear all;
close all;
clc;

rng(1);

global gs_bNet;
%% Parameters setting
s_nConst = 2;       % Constellation size (2 = BPSK)
s_nMemSize = 4;     % Number of taps
s_fTrainSize = 5000; % Training size
s_fBlocks = 5; %200;
%%%%%%%v_fSigWdB=  12; %30:40; %6:16; %% % Noise variance in dB

% RS encoder -  n = 255, t = 8, k = 239
s_nRSCodeSize = 8;          % Number of bits per symbol
s_nT = 16;                   % Number of error symbols correctable
s_nN = 2^s_nRSCodeSize-1;   % Number of coded symobls per block         
s_nK = s_nN - 2*s_nT;       % Number of uncoded symbols per block

s_nRSBlockSize = s_nRSCodeSize * s_nK; % number of bits in RS block
s_nRSWordSize = s_nRSCodeSize * s_nN; % number of bits in RS word
genpoly = rsgenpoly(s_nN,s_nK); % RS generative polynomial
        
gs_bNet = 0;        

s_nStates = s_nConst^s_nMemSize;    



% s_fEstErrVar = 0.1;   % Estimation error variance
% Frame size for generating noisy training
s_fFrameSize = 100; %1200;
s_fNumFrames = s_fTrainSize/s_fFrameSize; 

s_nChannels = 1;            % 1 - LTI channel;  2 - Poisson channel 

v_nCurves   = [...          % Curves
    1 ...                   % Deep Viterbi - real-time training - 1
    0 ....                  % Deep Viterbi - composite training
    0 ....                  % Deep Viterbi - initial training
    1 ...                   % Viterbi - perfect CSI - 1
    0 ....                  % Viterbi - CSI uncertainty
    0 ....                  % Viterbi - estimate channel
    ];


s_nCurves = length(v_nCurves);

v_stProts = strvcat(  ...
    'ViterbiNet, online training', ...
    'ViterbiNet, composite training',...
    'ViterbiNet, initial training',...  
    'Viterbi, full CSI', ...
    'Viterbi, initial CSI',...   
    'Viterbi, LS estimate');
v_stProts2 = strvcat(  ...
            'First tap (h)_1', ...
            'Second tap (h)_2',...
            'Third tap (h)_3',...  
            'Fourth tap (h)_4');
        
v_stPlotType = strvcat( '-rs', '--go',  '-g<', '-.b^',  ':kx',...
           '-g*', '-m>', '-mx', '-c^', '-cv');
v_stLegend = [];

if(s_nChannels == 1)
    % Exponentailly decaying channel
    v_fChannel = exp(-0.2*(0:(s_nMemSize-1)));    
    s_nMixtureSize = s_nStates;
elseif (s_nChannels == 2)
    % Poisson channel
    v_fChannel = exp(-0.2*(0:(s_nMemSize-1)));    
    s_nMixtureSize = 1.5*s_nStates;
end

% Channel model - periodic time variatios
v_nPers = 3*[17, 13, 11, 7];

s_fBERTh = 0.02; %0.35;

run ViterbiNeApp.mlapp
