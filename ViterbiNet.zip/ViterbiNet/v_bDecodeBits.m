% Function name - v_bDecodeBits
% Purpose - Decode bit stream
% Input arguments:
%   v_bInput - bits vector - data to decode
%   v_stCodes - strings vector - codes to use (in order of encoding)
% Output arguments:
%   v_bOutput - bits vector
function v_bOutput = v_bDecodeBits(v_bInput, v_stCodes)

global g_nWordSize ;     % Code word size
global g_nIntrlvSeed;    % Random interleaver seed

% Loop over codes to use, encode stream
bitsOut = v_bInput;

% Convolutional decode - 1 / 2 code rate
if (strcmp(v_stCodes,'CONV_ENC'))

	Trellis=poly2trellis(7,[171 133]);		
    tb = 2; % Traceback length for decoding
    % Create a ViterbiDecoder System object
    hVitDec = comm.ViterbiDecoder(Trellis, 'InputFormat', 'hard', ...
        'TracebackDepth', tb, 'TerminationMethod', 'Truncated');
    bitsOut = step(hVitDec, v_bInput); % Decode.

end

if (strcmp(v_stCodes,'RS_CONV_ENC'))
    hDec = comm.RSDecoder('BitInput',true);
	Trellis=poly2trellis(7,[171 133]);		
    tb = 2; % Traceback length for decoding
    % Create a ViterbiDecoder System object
    hVitDec = comm.ViterbiDecoder(Trellis, 'InputFormat', 'hard', ...
        'TracebackDepth', tb, 'TerminationMethod', 'Truncated');
    bitsTemp = step(hVitDec, v_bInput); % Decode Convolution.
    bitsOut = step(hDec, bitsTemp); % Decode RS.
end

if (strcmp(v_stCodes,'REP_3'))
    % Repetition (3,1)
    m_bRepMat = reshape(v_bInput, 3, []);
    % Decode the string based on majority
    bitsOut = transp(double((sum(m_bRepMat) > (3/2))));

end

% G3 decoder - RS, followed by convolution and interleaving
if (strcmp(v_stCodes,'G3_ENC'))
    % Loop over frame blocks
    s_nNumOfBlocks =  ceil(length(v_bInput)/g_nWordSize);
    bitsOut = [];
    for ii=1:s_nNumOfBlocks
        v_bCodedBits = v_bInput(1+(ii-1)*g_nWordSize: min(ii*g_nWordSize,length(v_bInput)));
        % de-interleave
        v_bDeIntrlvBits = randdeintrlv(v_bCodedBits, g_nIntrlvSeed);
        % Convolutional decoder - 1 / 2 code rate
        Trellis=poly2trellis(7,[171 155]);
        tb = 3; % Traceback length for decoding
        % Decode the string
        v_bDeConvBits = vitdec(v_bDeIntrlvBits,Trellis,tb,'trunc','hard'); %Hard decision  
        
        % RS decoder -  n = 255, t = 8, k = 239
        s_nRSCodeSize = 8;          % Number of bits per symbol
        s_nT = 8;                   % Number of error symbols correctable
        s_nN = 2^s_nRSCodeSize-1;   % Number of coded symobls per block         
        s_nK = s_nN - 2*s_nT;       % Number of uncoded symbols per block
        
        genpoly = rsgenpoly(s_nN,s_nK);
        
        % partition frame to blocks for RS decoder 
        s_nRSBlockSize = s_nRSCodeSize * s_nN; % number of bits in encoded RS block
        s_nNumOfRSBlocks = ceil(length(v_bDeConvBits)/s_nRSBlockSize);
        v_bRSUncodedBits = [];
        for jj=1:s_nNumOfRSBlocks
            v_bRSBits = v_bDeConvBits(1+(jj-1)*s_nRSBlockSize: min(jj*s_nRSBlockSize, length(v_bDeConvBits)));
            % RS encode each block
            v_bRSUncodedBits = [v_bRSUncodedBits ; v_bRSDecode(v_bRSBits, s_nRSCodeSize, s_nT, genpoly)];
        end
        
        bitsOut = [bitsOut ; v_bRSUncodedBits];
    end

end

v_bOutput = bitsOut;