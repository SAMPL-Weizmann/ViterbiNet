% Function name - v_bRSEncode
% Purpose - Reed Solomon encode bit stream block
% Input arguments:
%   v_bInput - bits vector - data to encode
%   s_nRScodeSize - integer - Reed solomon code size
%   s_nErrorSymbols - integer - number of correctable error symbols 
%   genpoly - polynomial - generator polynomial
% Output arguments:
%   v_bOutput - bits vector

function v_bOutput = v_bRSEncode(v_bInput, s_nRScodeSize, s_nErrorSymbols, genpoly)
% reshape bits to bytes
v_bInput=reshape(v_bInput,s_nRScodeSize,length(v_bInput)/s_nRScodeSize);
inputRSBytes=zeros(size(v_bInput,2),1);
for i=1:size(v_bInput,2)
    inputRSBytes(i)=bi2de(fliplr(v_bInput(:,i)'));
end
inputRSBytes = inputRSBytes';
% Convert bytes to Galois field elements GF(2^s_nRScodeSize)
msg = gf(inputRSBytes,s_nRScodeSize);
% Encode symbols
code = rsenc(msg,length(msg) + 2*s_nErrorSymbols ,length(msg),genpoly);
RScode=code.x;
RScode=vec2mat(RScode,1);
% Convert encoded symbols to bits
RSbits=zeros(s_nRScodeSize,length(RScode));
for i=1:length(RScode)
    byte=RScode(i);
    RSbits(:,i)=fliplr(de2bi(double(byte),s_nRScodeSize));
end

v_bOutput = RSbits(:);