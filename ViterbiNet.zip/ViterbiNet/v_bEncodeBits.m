% Function name - v_bEncodeBits
% Purpose - Encode bit stream
% Input arguments:
%   v_bInput - bits vector - data to encode
%   v_stCodes - strings vector - codes to use (in order of encoding)
% Output arguments:
%   v_bOutput - bits vector
function v_bOutput = v_bEncodeBits(v_bInput, v_stCodes)

global g_nBlockSize ;    % Frame block size
global g_nWordSize;      % Code word size
global g_nIntrlvSeed;    % Random interleaver seed

% Loop over codes to use, encode stream
bitsOut = v_bInput;

% Convolutional encoder - 1 / 2 code rate
if (strcmp(v_stCodes,'CONV_ENC'))

	Trellis=poly2trellis(7,[171 133]);		
    % Create a ConvolutionalEncoder System object
    hConvEnc = comm.ConvolutionalEncoder(Trellis);
    % Encode the string
    bitsOut = transp(step(hConvEnc,transp(v_bInput)));     

end

if (strcmp(v_stCodes,'RS_CONV_ENC'))

	Trellis=poly2trellis(7,[171 133]);		
    % Create a ConvolutionalEncoder System object
    % Input size must be an integer multiple of 9, the output size is an
    % integer multiple of 21
    hEnc = comm.RSEncoder('BitInput',true);
    hConvEnc = comm.ConvolutionalEncoder(Trellis);
    BitsTemp =  transp(step(hEnc,transp(v_bInput))); 
    % Encode the string
    bitsOut = transp(step(hConvEnc,transp(BitsTemp)));     

end
 
if (strcmp(v_stCodes,'REP_3'))
    % Repetition (3,1)
    m_bRepMat = repmat(v_bInput, 3, 1);
    % Encode the string
    bitsOut = transp(m_bRepMat(:));

end

% G3 encoder - RS, followed by convolution and interleaving
if (strcmp(v_stCodes,'G3_ENC'))
    % Loop over frame blocks
    s_nNumOfBlocks = ceil(length(v_bInput)/g_nBlockSize);
    bitsOut = [];
    for ii=1:s_nNumOfBlocks
        v_bUncodedBits = v_bInput(1+(ii-1)*g_nBlockSize: min(ii*g_nBlockSize, length(v_bInput)));        
        % RS encoder -  n = 255, t = 8, k = 239
        s_nRSCodeSize = 8;          % Number of bits per symbol
        s_nT = 8;                   % Number of error symbols correctable
        s_nN = 2^s_nRSCodeSize-1;   % Number of coded symobls per block         
        s_nK = s_nN - 2*s_nT;       % Number of uncoded symbols per block
        
        genpoly = rsgenpoly(s_nN,s_nK);
        
        % partition frame to blocks for RS encoder 
        s_nRSBlockSize = s_nRSCodeSize * s_nK; % number of bits in RS block
        
        
        s_nNumOfRSBlocks = ceil(length(v_bUncodedBits)/s_nRSBlockSize);
        v_bRSCodedBits = [];
        for jj=1:s_nNumOfRSBlocks
            v_bRSBits = v_bUncodedBits(1+(jj-1)*s_nRSBlockSize: min(jj*s_nRSBlockSize, length(v_bUncodedBits)));
            % RS encode each block
            v_bRSCodedBits = [v_bRSCodedBits ; v_bRSEncode(v_bRSBits, s_nRSCodeSize, s_nT, genpoly)];
        end

        % Convolutional encoder - 1 / 2 code rate
        Trellis=poly2trellis(7,[171 155]);		
        % Encode the string
        v_bConvCodedBits = transp(convenc(transp(v_bRSCodedBits), Trellis));    
        % interleave
        v_bIntrlvBits = randintrlv(v_bConvCodedBits, g_nIntrlvSeed);         
        bitsOut = [bitsOut ; v_bIntrlvBits];
        % Convert uncoded block size to coded block size on first iteration
        if (ii==1) 
            g_nWordSize = length(bitsOut); 
        end
    end

end

v_bOutput = bitsOut;